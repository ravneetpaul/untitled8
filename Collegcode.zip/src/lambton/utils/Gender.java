package lambton.utils;

public enum Gender {
    MALE,FEMALE,OTHERS
}
