package lambton.utils;

public enum Color {
    RED,YELLOW,BLACK,WHITE,PINK
}
