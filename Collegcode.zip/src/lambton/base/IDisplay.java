package lambton.base;

public interface IDisplay {//Interfaces
    public void display();
}
